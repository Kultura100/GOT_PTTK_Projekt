import $ from 'jquery';
window.$ = window.jQuery = $;
require('./bootstrap');
global.bootstrap = require('bootstrap');
require('./vendor/jsvalidation/js/jsvalidation');
require('datatables.net-bs5');