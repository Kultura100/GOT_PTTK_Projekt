<a
href="<?php echo e($attributes->get('url')); ?>"
data-bs-toggle="tooltip" data-bs-placement="top"
title="<?php echo e($attributes->get('title')); ?>"
type="button"
class="<?php echo e($attributes->get('class')); ?>">
<?php echo $slot; ?>

</a><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/components/datatables/action-link.blade.php ENDPATH**/ ?>