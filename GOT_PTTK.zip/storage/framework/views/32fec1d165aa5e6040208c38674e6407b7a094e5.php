<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/szlak.css')); ?>">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" />
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/szlak.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <h2>Grupy górskie</h2>
        <ul class="responsive-table">
            <?php $__currentLoopData = $grupy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="table-header">
                    <div class="col col-t"><?php echo e($grupa->nazwa); ?></div>
                </li>
                <h3 style="text-align:center;">Pasma górskie</h3>
                <?php $__currentLoopData = App\Models\Grupa::find($grupa->id)->pasma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="table-row">
                    <div class="col col-1"><?php echo e($pasma->nazwa); ?></div>
                    <div>
                        <a href="<?php echo e(route('szlak.szczegoly', ['id' => $pasma->id])); ?>">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                                Szczegóły
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </a>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/szlak/index.blade.php ENDPATH**/ ?>