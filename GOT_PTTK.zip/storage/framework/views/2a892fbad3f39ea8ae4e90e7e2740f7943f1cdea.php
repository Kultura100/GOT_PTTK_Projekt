<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/raport.css')); ?>">
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/raport.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <h1 style="float:none;"><?php echo e(__('Lista zgłoszeń')); ?></h1>       
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

        <?php endif; ?>
    </div>
    
    <ul class="responsive-table">
        <li class="table-header">
            <div class="col col-1">Imię i Nazwisko</div>
            <div class="col col-2">E-mail</div>
            <div class="col col-3">Nazwa wycieczki</div>
            <div class="col col-4"></div>
        </li>

        <?php $__currentLoopData = $wycieczkiZatw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczkiZatwierdzone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="table-row">
                <div class="col col-1">
                    <?php echo e($wycieczkiZatwierdzone->jakaKsiazeczka->jakiUser->imie); ?> <?php echo e($wycieczkiZatwierdzone->jakaKsiazeczka->jakiUser->nazwisko); ?>

                </div>
                <div class="col col-2">
                    <?php echo e($wycieczkiZatwierdzone->jakaKsiazeczka->jakiUser->email); ?>

                </div>                
                <div class="col col-3">
                    <?php echo e($wycieczkiZatwierdzone->jakaWycieczka->nazwa); ?>

                </div>
                <div class="col col-4">
                    <a href="<?php echo e(route('listaturystow.szczegoly', ['id' => $wycieczkiZatwierdzone->jakaWycieczka->id])); ?>">                         
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                                Szczegóły
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </a>
                </div>                
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/listaturystow/index.blade.php ENDPATH**/ ?>