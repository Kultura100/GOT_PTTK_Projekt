<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/raport.css')); ?>">
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/raport.js')); ?>"></script>
        <script>
        function zmien() {
            var element = document.getElementById("historia");
        if (document.getElementById('flexCheckDefault').checked) {      
            element.classList.toggle("d-none");
        } else    element.classList.toggle("d-none");
    }
        </script>
    
    <div class="container">
        <?php if (isset($component)) { $__componentOriginal440ae286f8f09d008911e33dcb596d0e8c6bdd79 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Toasts::class, []); ?>
<?php $component->withName('toasts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal440ae286f8f09d008911e33dcb596d0e8c6bdd79)): ?>
<?php $component = $__componentOriginal440ae286f8f09d008911e33dcb596d0e8c6bdd79; ?>
<?php unset($__componentOriginal440ae286f8f09d008911e33dcb596d0e8c6bdd79); ?>
<?php endif; ?>
        <h1 style="float:none;"><?php echo e(__('translations.wycieczki.title')); ?></h1> 
        <div class="d-flex flex-row-reverse mb-4 justify-center">
            <a href="<?php echo e(route('wycieczki.create')); ?>" type="button" class="btn btn-primary" role="button">
                <?php echo e(__('translations.wycieczki.label.create')); ?>

            </a>
            <div class="form-check pt-2">
                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" onclick="zmien()">
                <label class="form-check-label" for="flexCheckDefault">
                  Pokaz odbyte
                </label>
              </div>
        </div>
    </div>

    <ul class="responsive-table">
        <li class="table-header">
            <div class="col col-1"><strong>Nazwa</strong></div>
            <div class="col col-2"><strong>Data początku</strong></div>
            <div class="col col-3"><strong>Data końca</strong></div>
            <div class="col col-4"><strong>Pasmo</strong></div>
            <div class="col col-5"><strong>Ilość punktów</strong></div>
            <div class="col col-6"><strong>Operacje</strong></div>
        </li>
      
        <?php $__currentLoopData = $wycieczki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <li class="table-row">
                <div class="col col-1">
                    <!-- Nazwa wycieczki --><?php echo e($wycieczka->nazwa); ?>

                </div>
                <div class="col col-2">
                    <!-- data poczatku wycieczki --><?php echo e($wycieczka->dataod); ?>

                </div>
                <div class="col col-3">
                    <!-- data konca wycieczki --><?php echo e($wycieczka->datado); ?>

                </div>
                <div class="col col-4">
                    <!-- nazwa pasma --><?php if(null !== $wycieczka->wieleodcinkow->first()): ?> <?php echo e($wycieczka->wieleodcinkow->first()->wycieczka_odcinek2->pasmo->nazwa); ?><?php endif; ?>
                </div>
                <div class="col col-5">
                    <!-- ilosc zebranych punktow --><?php echo e($wycieczka->punkty); ?>

                </div>

                <div class="col col-6">
                <?php if(null !== $wycieczka->wieleodcinkow->first()): ?>
                    <a href="<?php echo e(route('wycieczki.szczegoly', ['id' => $wycieczka->id])); ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                            Szczegóły
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </a>
                <?php endif; ?>
                <?php if(null !== $wycieczka->wieleodcinkow->first()): ?>
                <a href="<?php echo e(route('wycieczki.zapisz', ['id' => $wycieczka->id])); ?>">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                        Zapisz się
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </a>
                <?php endif; ?>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    
<div id="historia" class="d-none">
    <ul class="responsive-table">
        <li class="table-header">
            <div class="col"></div>
            <div class="col"></div>
            <div class="col justify-center align-middle"><strong>Odbyte</strong></div>
            <div class="col"></div>
            <div class="col"></div>
        </li>
      
        <?php $__currentLoopData = $wycieczkiodbyte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <li class="table-row">
             <div class="col col-1">
                    <!-- Nazwa wycieczki --><?php echo e($wycieczka->nazwa); ?>

                </div>
                <div class="col col-2">
                    <!-- data poczatku wycieczki --><?php echo e($wycieczka->dataod); ?>

                </div>
                <div class="col col-3">
                    <!-- data konca wycieczki --><?php echo e($wycieczka->datado); ?>

                </div>
                <div class="col col-4">
                    <!-- nazwa pasma --><?php if(null !== $wycieczka->wieleodcinkow->first()): ?> <?php echo e($wycieczka->wieleodcinkow->first()->wycieczka_odcinek2->pasmo->nazwa); ?><?php endif; ?>
                </div>
                <div class="col col-5">
                    <!-- ilosc zebranych punktow --><?php echo e($wycieczka->punkty); ?>

                </div>

                <div class="col col-6">
                  <?php if(null !== $wycieczka->wieleodcinkow->first()): ?>
                    <a href="<?php echo e(route('wycieczki.szczegoly', ['id' => $wycieczka->id])); ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                            Szczegóły
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </a>
                    <?php endif; ?>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
    </div>  
    
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/wycieczki/index.blade.php ENDPATH**/ ?>