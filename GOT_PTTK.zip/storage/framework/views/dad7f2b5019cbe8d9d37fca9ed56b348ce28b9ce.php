<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/szlak.css')); ?>">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" />
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/szlak.js')); ?>"></script>
     <?php $__env->endSlot(); ?>

    <style>
        .list-group-item.active {
            z-index: 2;
            color: #fff;
            background-color: #3490dc;
            border-color: #3490dc;
            text-align: left;
            font-size: 20px;
            font-weight: bold;

        }

        .list-group-item {
            position: relative;
            display: block;
            padding: 0.5rem 1rem;
            color: #212529;
            text-decoration: none;
            background-color: #fff;
            border: 1px solid rgba(0, 0, 0, 0.125);
            text-align: left;
            font-size: 15px;

        }

        #prawo{
            float: right;
        }

    </style>

    <div class="container">
        <!-- <h2>Grupy</h2> -->
        <!-- <h2><small>Grupy górskie</small></h2> -->
        <ul class="list-group">
            
            <?php if($punkty->count()): ?>
                <?php $__currentLoopData = $punkty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item active">
                    <?php
                    if( strpos($punkt->nazwa, '(') !== false){
                        $tablice = explode("(", $punkt->nazwa, strlen($punkt->nazwa));
                        print("<div class='text-left'>$tablice[0] <span id='prawo'>($tablice[1]</span></div>");
                    } 
                    else{
                        print($punkt->nazwa);
                    }
                    ?>
                    </li>
                 
                    <?php $__currentLoopData = App\Models\Punkt::find($punkt->id)->punktnaliscie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punkcik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($punkcik->nazwa); ?>

                            <span id='prawo'><?php echo e($punkt->dajpunkty($punkcik->id,$punkt->id)); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <ul class="list-group">
                    <li class="list-group-item active"> Brak punktow</li>
                </ul>
            <?php endif; ?>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/szlak/szczegoly.blade.php ENDPATH**/ ?>