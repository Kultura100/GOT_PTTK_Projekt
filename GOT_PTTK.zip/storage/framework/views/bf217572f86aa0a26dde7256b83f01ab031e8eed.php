<?php $attributes = $attributes->exceptProps(['styles' => '', 'scripts' => '']); ?>
<?php foreach (array_filter((['styles' => '', 'scripts' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>GotPTTK</title>
        
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        
        <?php echo e($styles); ?>

    </head>
    <body>
        <?php echo e($slot); ?>

    </body>
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    
    <?php echo e($scripts); ?> 
</html><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/layouts/base.blade.php ENDPATH**/ ?>