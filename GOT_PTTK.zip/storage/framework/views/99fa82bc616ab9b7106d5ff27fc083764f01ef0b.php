<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/osiagniecia.css')); ?>">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" />
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/osiagniecia.js')); ?>"></script>
        <script>
            $('#search').on('keyup', function() {
                        $value = $(this).val();
                        $.ajax({
                            type: 'get',
                            // url: '<?php echo e(URL::to('search')); ?>',
                            url: '/osiagniecia/search',
                            data: {
                                "_token": "<?php echo e(csrf_token()); ?>",
                                'search': $value,},
                            success: function(data) {
                                $('.wycieczkizawartosc').html(data);
                            }
                        });
                    })
        </script>

     <?php $__env->endSlot(); ?>
    <div class="col-lg-10 mx-auto mb-4">
        <div class="section-title text-center ">
            <h3 class="top-c-sep">Aktywne Wycieczki</h3>
            <p>Wykaz obecnie odbywających sie wycieczek</p>
        </div>
    </div>
    <div class="row">
        <div class="wycieczkizawartosc row">
            
            <?php $__currentLoopData = $ksiazeczka->ksiazeczkawycieczki->where('zatwierdzona',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6">
                    <div class="job-box d-md-flex align-items-center justify-content-between mb-30">
                        <div class="job-left my-4 d-md-flex align-items-center flex-wrap">
                            <div class="img-holder mr-md-4 mb-md-0 mb-4 mx-auto mx-md-0 d-md-none d-lg-flex">
                                <!-- tutaj zdjęcie -->
                            </div>
                            <div class="job-content">
                                <h5 class="text-center text-md-left"><?php echo e($wycieczka->jakawycieczka->nazwa); ?></h5>
                                <ul class="d-md-flex text-capitalize ff-open-sans">
                                    <li class="mr-md-4">
                                        <i class="zmdi zmdi-time mr-2"></i> <?php echo e($wycieczka->jakawycieczka->dataod); ?> do 
                                        <?php echo e($wycieczka->jakawycieczka->datado); ?>

                                    </li>&nbsp&nbsp
                                    <li class="mr-md-4">
                                        <i class="zmdi zmdi-parking mr-2"> </i> <?php echo e($wycieczka->jakawycieczka->punkty); ?>

                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('osiagniecia.szczegoly', ['id' => $wycieczka->jakawycieczka->id])); ?>">                         
                                        <button class="btn btn-primary">
                                            Szczegóły
                                        </button>
                                  </a></li>
                                </ul>                             
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>




    <div class="col-lg-10 mx-auto mb-4">
        <div class="section-title text-center ">
            <h3 class="top-c-sep">Osiągnięcia</h3>
            <p>Wykaz osiągnieć zdobytych przez użytkownika</p>
        </div>
    </div>
    <div class="row">
        <div class="md-form mt-0">
            <input class="form-control" type="text" id="search" name="search" placeholder="Szukaj wycieczki"
                aria-label="Szukaj wycieczki">
        </div>
        <div class="wycieczkizawartosc row">
            
            <?php $__currentLoopData = $ksiazeczka->ksiazeczkawycieczki->where('zatwierdzona',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6">
                    <div class="job-box d-md-flex align-items-center justify-content-between mb-30">
                        <div class="job-left my-4 d-md-flex align-items-center flex-wrap">
                            <div class="img-holder mr-md-4 mb-md-0 mb-4 mx-auto mx-md-0 d-md-none d-lg-flex">
                                <!-- tutaj zdjęcie -->
                            </div>
                            <div class="job-content ">
                                <h5 class="text-center text-md-left"><?php echo e($wycieczka->jakawycieczka->nazwa); ?></h5>
                                <ul class="d-md-flex text-capitalize ff-open-sans">
                                    <li class="mr-md-4">
                                        <i class="zmdi zmdi-time mr-2"></i> <?php echo e($wycieczka->jakawycieczka->dataod); ?> do 
                                        <?php echo e($wycieczka->jakawycieczka->datado); ?>

                                    </li>&nbsp&nbsp
                                    <li class="mr-md-4">
                                        <i class="zmdi zmdi-parking mr-2"> </i> <?php echo e($wycieczka->jakawycieczka->punkty); ?>

                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('osiagniecia.szczegolyzatw', ['id' => $wycieczka->jakawycieczka->id])); ?>">                         
                                        <button class="btn btn-primary ">
                                            Szczegóły
                                        </button>
                                </a></li>
                                </ul>                             
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <section class="py-5 mb-5">
        <div class="section-title text-center ">
            <h3 class="top-c-sep">Odznaki</h3>
            <p>Gablota zdobytych odznak</p>
        </div>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $odznaka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odznaki): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $odznaki->odznakaturysty_odznaka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odznaczka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card mb-3">
                                <img src="<?php echo e($odznaczka->zrodlo); ?>" class="OdznakiImg"
                                    alt="<?php echo e($odznaczka->nazwa); ?>">
                                <div class="cart-body">
                                    <p class="p-3"><b><?php echo e($odznaczka->nazwa); ?></b> <br>
                                        
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/osiagniecia/index.blade.php ENDPATH**/ ?>