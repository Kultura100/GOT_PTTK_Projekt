<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/klient.css')); ?>">
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
      <script src="<?php echo e(asset('js/klient.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
    <?php if(Gate::check('log-viewer')): ?>
    <div class="container">
      <h1><?php echo e(__('translations.uzytkownik.title')); ?></h1>
      <div class="d-flex flex-row-reverse mb-4">
        <a href="<?php echo e(route('uzytkownik.create')); ?>"
        type="button"
        class="btn btn-light"
        role="button">
        <?php echo e(__('translations.uzytkownik.label.create')); ?>

        </a>
      </div>
      <div id="no-more-tables">
      <table class="table" style="width: 100%;" id="tabelka">
      <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('translations.uzytkownik.attribute.email')); ?></th>
          <th><?php echo e(__('translations.uzytkownik.attribute.haslo')); ?></th>
          <th><?php echo e(__('translations.uzytkownik.attribute.imie')); ?></th>
          <th><?php echo e(__('translations.uzytkownik.attribute.nazwisko')); ?></th>
          <th><?php echo e(__('translations.uzytkownik.attribute.telefon')); ?></th>
          <th><?php echo e(__('translations.attribute.created_at')); ?></th>
          <th><?php echo e(__('translations.attribute.updated_at')); ?></th>
          <th class="always-visible"></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $klienci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($klient->id); ?></td>
          <td><?php echo e($klient->email); ?></td>
          <td>*********</td>
          <td><?php echo e($klient->imie); ?></td>
          <td><?php echo e($klient->nazwisko); ?></td>
          <td><?php echo e($klient->telefon); ?></td>
          <td><?php echo e($klient->created_at); ?></td>
          <td><?php echo e($klient->updated_at); ?></td>
          <td>
            <div class="btn-group" role="group" aria-label="action buttons">              
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.datatables.action-link','data' => ['class' => 'btn btn-primary','url' => ''.e(route('uzytkownik.edit', ['id' => $klient->id])).'','title' => ''.e(__('translations.uzytkownik.label.edit')).'']]); ?>
<?php $component->withName('datatables.action-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-primary','url' => ''.e(route('uzytkownik.edit', ['id' => $klient->id])).'','title' => ''.e(__('translations.uzytkownik.label.edit')).'']); ?>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                  </svg>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>              
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
      </div>
      <div class="justify-center">
        <?php if(!empty($klienci)): ?>
         <?php echo e($klienci->links()); ?>   
        <?php endif; ?>
    </div>
    </div>
    <?php else: ?>
    <?php $__currentLoopData = $klienci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Klient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form id="klient-form" method="POST" action="<?php echo e(route('uzytkownik.update', ['id' => $Klient->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
  
    <div class="container rounded bg-white mt-5 mb-5">
      <div class="row">
          <div class="col-md-3 border-right">
              <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"><span class="font-weight-bold"><?php echo e($Klient->Imie); ?> <?php echo e($Klient->Nazwisko); ?> </span><span class="text-black-50"><?php echo e($Klient->Email); ?></span><span> </span></div>
          </div>
          <div class="col-md-5 border-right">
              <div class="p-3 py-5">
                  <div class="d-flex justify-content-between align-items-center mb-3">
                      <h4 class="text-right">Ustawienia Profilu</h4>
                  </div>
                  <div class="row mt-2">
                      <div class="col-md-6"><label class="labels">Imie</label><input type="text" class="form-control" placeholder="Podaj imie" name="imie" value="<?php echo e($Klient->imie); ?>"></div>
                      <div class="col-md-6"><label class="labels">Nazwisko</label><input type="text" class="form-control" name="nazwisko" value="<?php echo e($Klient->nazwisko); ?>" placeholder="Podaj nazwisko"></div>
                      <div class="col-md-6"><label class="labels">Email</label><input type="text" class="form-control" name="email" value="<?php echo e($Klient->email); ?>" placeholder="Podaj Email"></div>
                  </div>
                  <input type="hidden" class="form-control" name="nazwa" value="<?php echo e($Klient->imie); ?> <?php echo e($Klient->nazwisko); ?>">
                  <div class="row mt-3">
                      <div class="col-md-12"><label class="labels">Numer Telefonu</label><input type="text" class="form-control" placeholder="Podaj numer telefonu" name="telefon" value="<?php echo e($Klient->telefon); ?>"></div>
                      <div class="col-md-12"><label class="labels">Punkty</label><input type="text" class="form-control" placeholder="Podaj ulice" name="punkty" value="<?php echo e($Klient->punkty); ?>" disabled></div>
                  </div>
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                  <div class="mt-5 text-center">
                    <input class="btn btn-primary profile-button" type="submit" value="Zapisz Profil">
                  </div>
              </div>
          </div>
          <div class="col-md-4">
              <div class="p-3 py-5">
                  <div class="d-flex justify-content-between align-items-center experience"><span>Zmien Haslo</span><span class="border px-3 p-1 add-experience"><i class="fa fa-plus"></i>&nbsp;Haslo</span></div><br>
                  <div class="col-md-12"><label class="labels">Podaj haslo</label><input type="password" class="form-control" name="password" placeholder="Podaj Haslo" value="<?php echo e($Klient->password); ?>"></div> <br>
                  <div class="col-md-12"><label class="labels">Potworz haslo</label><input type="password" class="form-control" name="password_confirmation" placeholder="Potworz haslo" value="<?php echo e($Klient->password); ?>"></div>
              </div>
          </div>
      </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </form>
  <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/uzytkownik/index.blade.php ENDPATH**/ ?>