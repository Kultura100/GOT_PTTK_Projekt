<style>
/* * {
    box-sizing: border-box;
} */

section{
    display: flex;
}

header{
    margin: 0;
    padding: 0;
}

.carousel-item{
    position: relative;
    height: 200px;
    width: 200px;
    background-position: center;
    background-size: cover;
    z-index: 0;

}

.hero-shadow {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: (0, 0, 0, 0.6);
    z-index: -1;
}

.container {
  margin-right: 0 !important; 
  margin-left: 0 !important; 
  padding: 0;
  box-sizing: 0 !important;
  max-width: 100% !important;
} 
</style>


<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dashboard.css')); ?>">
       <?php $__env->endSlot(); ?>


<section>
<div class="container h-100 d-flex flex-column justify-content-center align-items-center text-left">
    <h1 class="mt-2">Kolory szlaków górskich</h1>
    <div class="text-left">
        <ul class="list-group list-group-flush ">
            <li class="list-group-item fs-4"><img src="<?php echo e(URL::asset('/images/szlaki/Czerwony.png')); ?>" class="img-fluid" width=20% height=20% alt="logo"><b>SZLAK CZERWONY</b> - To szlak główny, którym najprawdopodobniej wędrówka będzie najciekawsza. 
                </li>
            <li class="list-group-item fs-4"><img src="<?php echo e(URL::asset('/images/szlaki/Niebieski.png')); ?>" class="img-fluid" width=20% height=20% alt="logo"><b>SZLAK NIEBIESKI</b> - To trasa długodystansowa, ale nie jest to główny szlak.</li>
            <li class="list-group-item fs-4"><img src="<?php echo e(URL::asset('/images/szlaki/Zielony.png')); ?>" class="img-fluid" width=20% height=20% alt="logo"><b>SZLAK ZIELONY</b> - Szlak doprowadzający do ciekawych lub charakterystycznych miejsc.</li>
            <li class="list-group-item fs-4"><img src="<?php echo e(URL::asset('/images/szlaki/Zolty.png')); ?>" class="img-fluid" width=20% height=20% alt="logo"><b>SZLAK ŻÓŁTY</b> - Kolor ten oznacza szlaki łącznikowe, czasami oznacza też szlaki dojściowe.</li>
            <li class="list-group-item fs-4"><img src="<?php echo e(URL::asset('/images/szlaki/Czarny.png')); ?>" class="img-fluid" width=20% height=20% alt="logo"><b>SZLAK CZARNY</b> - Szlak dojściowy.</li>
      </ul>
    </div>
</div>


  <img src="<?php echo e(URL::asset('/images/Tatry_szlaki.png')); ?>" class="img-fluid d-flex flex-column justify-content-center" width="72%" alt="szlaki">
    
    





</section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/dashboard.blade.php ENDPATH**/ ?>