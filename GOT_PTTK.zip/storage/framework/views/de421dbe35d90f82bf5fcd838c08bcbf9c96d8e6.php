<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/odznaki.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"/>
    <style>
        .rounded{
            border-top: 8px solid #304b5f;
            border-radius: 5px;
        }
        </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
      <script src="<?php echo e(asset('js/odznaki.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
    
    <main>
        <section class="py-5 mb-5">

            <div class="container text-center py5">
                <p class="display-4">Odznaki</p>
                <p class="display-6">W góry</p>
            </div>
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $odznaki; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odznaka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($odznaka->id == 4): ?><hr class="rounded"> <p class="display-6 text-center">Popularna</p><?php endif; ?>
                    <?php if($odznaka->id == 5): ?><hr class="rounded"> <p class="display-6 text-center">Małe</p><?php endif; ?>
                    <?php if($odznaka->id == 8): ?><hr class="rounded"> <p class="display-6 text-center">Duże</p><?php endif; ?>
                    <?php if($odznaka->id == 11): ?><hr class="rounded"> <p class="display-6 text-center">Wytrwałości</p><?php endif; ?>
                    <?php if($odznaka->id == 12): ?><hr class="rounded"> <p class="display-6 text-center">Przodownika</p><?php endif; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card mb-3">
                            <img src="<?php echo e($odznaka->zrodlo); ?>" class="OdznakiImg" alt="<?php echo e($odznaka->nazwa); ?>">
                            <div class="cart-body">
                                <p class="p-3"><b><?php echo e($odznaka->nazwa); ?></b> <br> <?php echo e(intval($odznaka->wymaganepunkty) ? "Wymagane punkty: ".$odznaka->wymaganepunkty:"Wymagania: ".$odznaka->wymaganepunkty); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/odznaki/index.blade.php ENDPATH**/ ?>