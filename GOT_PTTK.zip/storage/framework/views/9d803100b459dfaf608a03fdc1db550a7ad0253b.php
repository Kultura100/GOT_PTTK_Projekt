<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/ranking.css')); ?>">
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
        <script src="<?php echo e(asset('js/ranking.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="articles card">
                    <div class="card-header d-flex align-items-center">
                        <h2 class="h3">Ranking 10 najlepszych wspinaczy</h2>
                    </div>
                    <div class="card-body no-padding">
                        
                        <?php $__currentLoopData = $kwerenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miejsca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="item d-flex align-items-center">
                                <div class="image"><img src="https://bootdey.com/img/Content/avatar/avatar6.png"
                                        alt="..." class="img-fluid rounded-circle"></div>
                                <div class="text">
                                    <?php if($loop->iteration <= 3): ?>
                                    <i class="fas fa-trophy"
                                        <?php if($loop->iteration == 1): ?> style="color:#ffbb00" <?php elseif($loop->iteration == 2): ?> style="color:#9c9c9c" <?php elseif($loop->iteration == 3): ?> style="color:#b88700" <?php endif; ?>>
                                        <?php echo e($loop->iteration); ?></i><?php else: ?><div class="" style="font-weight: 900; font-family: 'Font Awesome 6 Free';"><?php echo e($loop->iteration); ?></div><?php endif; ?>
                                    <h3 class="h5" <?php if(Auth::user()->imie == $uzytkownicy->where('id', key($kwerenda))->first()->imie && Auth::user()->nazwisko == $uzytkownicy->where('id', key($kwerenda))->first()->nazwisko): ?> style="font-weight:bold" <?php endif; ?>>
                                        <?php echo e($imie = $uzytkownicy->where('id', key($kwerenda))->first()->imie); ?>

                                        <?php echo e($nazwisko = $uzytkownicy->where('id', key($kwerenda))->first()->nazwisko); ?>

                                    </h3>
                                    <small>Ilosc odznak: <?php echo e($miejsca); ?></small>
                                    <input type="hidden" value="<?php echo e($miejsca); ?>" name="wynik">
                                    <input type="hidden" value="<?php echo e($imie); ?> <?php echo e($nazwisko); ?>" name="imieinazwisko">
                                </div>
                            </div>
                            
                            <?php
                                next($kwerenda);
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wykresowa">
                <div class="articles card">
                    <div class="card-header d-flex justify-content-between">
                        <h2 class="h3">Wykres</h2>
                        <div class="p-2">
                            <div class="dropdown rozwijanemenu">
                                <button class="" type="button" id="dropdownMenuButton"
                                    style="border:none;">
                                    <i class='fa fa-ellipsis-v float-right'></i>
                                </button>
                                <div class="dropdown-menu rozwijanemenu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" id="drukowanko" href="#">Wydrukuj wykres</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body no-padding" id="contenernawykres">
                        <div>
                            <canvas id="myChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/ranking/index.blade.php ENDPATH**/ ?>