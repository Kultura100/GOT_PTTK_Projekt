<nav class="navbar navbar-expand-md navbar-light fixed-top bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(URL::asset('/images/logo-pttk.png')); ?>" width="50" height="50" alt="ikona">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar"
            aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar">

            <ul class="navbar-nav me-auto mb-2 mb-md-0">

                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('dashboard'),'active' => request()->routeIs('dashboard')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
                        Strona Główna
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>

                

                
                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('osiagniecia.index'),'active' => request()->routeIs('osiagniecia.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('osiagniecia.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('osiagniecia.index'))]); ?>
                        <!-- osiagniecia.index -->
                        <?php echo e(__('translations.osiagniecia.title')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>

                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('odznaki.index'),'active' => request()->routeIs('odznaki.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('odznaki.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('odznaki.index'))]); ?>
                        <!-- odznaki.index -->
                        <?php echo e(__('translations.odznaki.title')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>

                

                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('ranking.index'),'active' => request()->routeIs('ranking.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ranking.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('ranking.index'))]); ?>
                        <!-- ranking.index -->
                        Ranking
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>

                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('wycieczki.index'),'active' => request()->routeIs('wycieczki.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('wycieczki.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('wycieczki.index'))]); ?>
                        <!-- wycieczki.index -->
                        <?php echo e(__('translations.wycieczki.title')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>

                <li class="nav-item">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('szlak.index'),'active' => request()->routeIs('szlak.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('szlak.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('szlak.index'))]); ?>
                        <!-- szlak.index -->
                        <?php echo e(__('translations.szlak.title')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </li>
                <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('przodownik')): ?>
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('obowiazki.index'),'active' => request()->routeIs('obowiazki.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('obowiazki.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('obowiazki.index'))]); ?>
                            <!-- obowiazki.index -->
                            <?php echo e(__('translations.obowiazki.title')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('przodownik')): ?>
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['href' => route('listaturystow.index'),'active' => request()->routeIs('listaturystow.index')]]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('listaturystow.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('listaturystow.index'))]); ?>
                            Lista zgłoszeń
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                <?php endif; ?>



            </ul>
            <div class="navbar-nav dropdown">
                <div class="notification">
                    <div class="notBtn" href="#">
                        <?php if(isset($powiadomienie)): ?>
                        <?php if($powiadomienie->count() > 0): ?>
                        
                            <?php $__currentLoopData = $powiadomienie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $powiadomienia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="number"><?php echo e($loop->iteration); ?></div>
                                <i class="fa-regular fa-bell"></i>
                                <div class="box">
                                    <div class="display">
                                        <div class="cont">
                                            <?php
                                                $dzisiaj = new DateTime();
                                                $przodownikdata = new DateTime($powiadomienia->created_at);
                                                if($dzisiaj->format('Y-m-d') == $przodownikdata->format('Y-m-d'))
                                                {
                                                    print(" <div class='sec new'> ");
                                                }
                                                else {
                                                    print(" <div class='sec'> ");
                                                }
                                            ?>
                                                
                                                <div class="profCont">
                                                    <img class="profile"
                                                        src="https://bootdey.com/img/Content/avatar/avatar6.png">
                                                </div>
                                                <div class="txt"><?php echo e($powiadomienia->tekst); ?></div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <i class="fa-regular fa-bell"></i>
                            <div class="box">
                                <div class="display">
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <i class="fa-regular fa-bell"></i>
                        <div class="box">
                            <div class="display">
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <a href="#" class="nav-link dropdown-toggle" id="profile" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    <img src="<?php echo e(url('/images/avatars/blank.png')); ?>" alt="USER_NAME" width="32" height="32"
                        class="rounded-circle">
                    <?php echo e(Auth::user()->imie); ?> <?php echo e(Auth::user()->nazwisko); ?>

                </a>
                <ul class="dropdown-menu dropdown-menu-end text-small" aria-labelledby="profile">
                    <li>
                        <?php if(Auth::user()->hasRole('admin')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('uzytkownik.index')); ?>"
                                aria-disabled="true">Zarządzaj użytkownikami</a>
                        <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e(route('uzytkownik.index')); ?>"
                                aria-disabled="true">Profil</a>
                        <?php endif; ?>
                    </li>
                    <li><a class="dropdown-item disabled" href="">Ustawienia</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><?php echo e(__('Wylogowanie')); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>