<div class="float-end">
    <div class="toast-container">
      <?php if(session('success')): ?>
        <?php if(is_array(session('success'))): ?>
          <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 alert alert-success" type="success">
              <?php echo e($message); ?>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <div class="mb-4 alert alert-success" type="success">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>
      <?php endif; ?>
      <?php if(session('warning')): ?>
        <?php if(is_array(session('warning'))): ?>
          <?php $__currentLoopData = session('warning'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 alert alert-warning" type="warning">
              <?php echo e($message); ?>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <div class="mb-4 alert alert-warning" type="warning">
            <?php echo e(session('warning')); ?>

          </div>
        <?php endif; ?>
      <?php endif; ?>   
      <?php if(session('danger')): ?>
        <?php if(is_array(session('danger'))): ?>
          <?php $__currentLoopData = session('danger'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 alert alert-danger" type="danger">
              <?php echo e($message); ?>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <div class="mb-4 alert alert-danger" type="danger">
            <?php echo e(session('danger')); ?>

          </div>
        <?php endif; ?>
      <?php endif; ?>   
    </div>
  </div><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/components/toasts.blade.php ENDPATH**/ ?>