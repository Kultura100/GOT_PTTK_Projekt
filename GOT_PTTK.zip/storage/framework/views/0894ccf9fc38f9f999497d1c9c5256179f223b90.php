<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/uzytkownik.css')); ?>">
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
      <script type="text/javascript" src="<?php echo e(asset('js/uzytkownik.js')); ?>"></script>
      <?php echo JsValidator::formRequest('App\Http\Requests\Uzytkownik\UzytkownikRequest'); ?>

     <?php $__env->endSlot(); ?>
    <div class="container">
      <h1><?php echo e(__('translations.uzytkownik.title')); ?></h1>
      <div class="card">
          <div class="card-body">
                <h5 class="card-title">
                    <?php if(isset($edit) && $edit === true): ?>  
                        <?php echo e(__('translations.uzytkownik.label.edit')); ?>

                    <?php else: ?>
                        <?php echo e(__('translations.uzytkownik.label.create')); ?>

                    <?php endif; ?>
                </h5>
              <form id="uzytkownik-form" method="POST"
                <?php if(isset($edit) && $edit === true): ?> 
                action="<?php echo e(route('uzytkownik.update', ['id' => $klient->id])); ?>"
                <?php else: ?>
                action="<?php echo e(route('uzytkownik.store')); ?>"
                <?php endif; ?>
              >
              <?php echo csrf_field(); ?>
              <?php if(isset($edit) && $edit === true): ?> 
                <?php echo method_field('PATCH'); ?>
              <?php endif; ?>
            <div class="row mb-3">
                <label for="uzytkownik-imie" class="col-sm-2 col-form-label">
                    <?php echo e(__('translations.uzytkownik.attribute.imie')); ?>

                </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control <?php $__errorArgs = ['imie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="imie"
                    id="uzytkownik-imie" 
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->imie); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('imie')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['imie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row mb-3">
                <label for="uzytkownik-nazwisko" class="col-sm-2 col-form-label">
                    <?php echo e(__('translations.uzytkownik.attribute.nazwisko')); ?>

                </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control <?php $__errorArgs = ['nazwisko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nazwisko"
                    id="uzytkownik-nazwisko"
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->nazwisko); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('nazwisko')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['nazwisko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


            <div class="row mb-3">
                <label for="uzytkownik-telefon" class="col-sm-2 col-form-label">
                    <?php echo e(__('translations.uzytkownik.attribute.telefon')); ?>

                </label>
                <div class="col-sm-10">
                    <input type="number" class="form-control <?php $__errorArgs = ['telefon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefon"
                    id="uzytkownik-telefon"
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->telefon); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('telefon')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['telefon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row mb-3">
                <label for="uzytkownik-email" class="col-sm-2 col-form-label">
                    <?php echo e(__('translations.uzytkownik.attribute.email')); ?>

                </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                    id="uzytkownik-email"
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->email); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('email')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>


            <div class="row mb-3">
                <label for="uzytkownik-haslo" class="col-sm-2 col-form-label">
                    <?php echo e(__('translations.uzytkownik.attribute.haslo')); ?>

                </label>
                <div class="col-sm-10">
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                    id="uzytkownik-password"
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->password); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('password')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row mb-3">
                <label for="uzytkownik-haslo" class="col-sm-2 col-form-label">
                   Potwierdz haslo
                </label>
                <div class="col-sm-10">
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation"
                    id="uzytkownik-password-confirmation"
                    <?php if(isset($klient)): ?>
                        Value="<?php echo e($klient->password); ?>"
                    <?php else: ?>
                        value="<?php echo e(old ('password')); ?>"
                    <?php endif; ?>
                    >
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <?php echo e($message); ?>

                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

              <div class="d-flex justify-content-end mb-3 ">
                  <div class="btn-group" role="group" aria-label="Cancel or submit form">
                      <a href="<?php echo e(route('uzytkownik.index')); ?>" type="submit" class="btn btn-danger">
                        <?php echo e(__('translations.buttons.cancel')); ?>

                      </a>
                      <button type="submit" class="btn btn-primary">
                          <?php if(isset($edit) && $edit === true): ?>
                          <?php echo e(__('translations.buttons.update')); ?>

                          <?php else: ?>
                          <?php echo e(__('translations.buttons.store')); ?>

                          <?php endif; ?> 
                      </button>
                    </div>
                </div>
            </form>
          </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/uzytkownik/create.blade.php ENDPATH**/ ?>