<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/szczegoly_wycieczki.css')); ?>">
        <style>
            #tekst{
                background: cornsilk;
                border: 1px solid black;
                border-radius: 5px;
                padding: 5px;
            }
            </style>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('scripts', null, []); ?> 
        <script src="https://printjs-4de6.kxcdn.com/print.min.js"></script>
        <script>
            $('#raport').click(function() {
                printJS('tabela', 'html');
            });
        </script>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <h1>Szczegóły wycieczki</h1>        
        <div class="d-flex flex-row-reverse m-4">
            <a href="<?php echo e(route('wycieczki.index')); ?>" type="button" class="btn btn-primary" role="button">
                <?php echo e(__('translations.wycieczki.label.back')); ?>

            </a>

            <div class="d-flex flex-row-reverse">
                <button type="button" class="btn btn-info" id="raport">Raport</button>
            </div>
        </div>
        <div class="text-left mt-5 mb-3 d-flex flex-column">
           <div> <strong>Imie i nazwisko:</strong> 
            <?php echo e($wycieczkiSzczeg->uzytkownikWycieczka->imie); ?> <?php echo e($wycieczkiSzczeg->uzytkownikWycieczka->nazwisko); ?></div>
            <div>
                <strong>Punkt początkowy:</strong>
                <?php if($wycieczkiSzczeg->wieleodcinkow->first()->odwrocony == 1): ?>
                            <?php echo e($wycieczkiSzczeg->wieleodcinkow->first()->wycieczka_odcinek2->punktkoncz->nazwa); ?>

                        <?php else: ?>
                            <?php echo e($wycieczkiSzczeg->wieleodcinkow->first()->wycieczka_odcinek2->punktpocz->nazwa); ?>

                        <?php endif; ?>
            </div>
            <div>
                <strong>Punkt końcowy:</strong>
                <?php if($wycieczkiSzczeg->wieleodcinkow->last()->odwrocony == 0): ?>
                            <?php echo e($wycieczkiSzczeg->wieleodcinkow->last()->wycieczka_odcinek2->punktkoncz->nazwa); ?>

                        <?php else: ?>
                            <?php echo e($wycieczkiSzczeg->wieleodcinkow->last()->wycieczka_odcinek2->punktpocz->nazwa); ?>

                        <?php endif; ?>
            </div>
        </div>
        
        <table class="table" id="tabela">            
            <thead>                
                <tr>
                    <th scope='col'>Odcinek</th>
                    <th scope='col'>Status</th>
                    <th scope='col'>Punkty</th>                    
                </tr>
            </thead>
            <tbody>                
                <?php $__currentLoopData = $wycieczkiSzczeg->wieleodcinkow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odcineczek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                        <td>
                                <?php if($odcineczek->odwrocony == 1): ?>
                                    <?php echo e($odcineczek->wycieczka_odcinek2->punktkoncz->nazwa); ?> -
                                    <?php echo e($odcineczek->wycieczka_odcinek2->punktpocz->nazwa); ?>,
                                <?php else: ?>
                                    <?php echo e($odcineczek->wycieczka_odcinek2->punktpocz->nazwa); ?> -
                                    <?php echo e($odcineczek->wycieczka_odcinek2->punktkoncz->nazwa); ?>,
                                <?php endif; ?> 
                        </td>
                        <td>
                            <?php if($odcineczek->id_status == 1): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="green" class="bi bi-check2" viewBox="0 0 16 16">
                                <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                              </svg>
                                <?php else: ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="red" class="bi bi-exclamation-square" viewBox="0 0 16 16">
                                        <g>
                                        <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                        <path d="M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z"/>
                                        </g>
                                    </svg> 
                                    <strong>- <?php echo e($odcineczek->status->nazwa); ?></strong>
                            <?php endif; ?>                        
                        </td>
                        <td style="text-align: right;">
                            <?php echo e($odcineczek->liczba_punktow); ?>

                        </td>                                   
                    </tr>                    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
            </tbody>
            <tfoot>
                <tr>                    
                    <th>                        
                    </th>
                    <th id="suma" style="text-align:left;">Suma: </th>
                    <th style="text-align: right;">
                        <?php
                        $x = 0;
                            foreach ($wycieczkiSzczeg->wieleodcinkow as $odcineczek)
                            {
                            $x+=$odcineczek->liczba_punktow;                            
                            }
                            echo $x;
                        ?>
                    </th>                   
                </tr>
            </tfoot>      
        </table>  
    </div>
    <div style="float:right">
        
        <a href="<?php echo e(route('listaturystow.zapisz', ['id' => $wycieczkiSzczeg->id])); ?>">
        
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'hover:bg-green-700']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'hover:bg-green-700']); ?>
                Zaakceptuj
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </a>
    </div>
    <h2> Zdjęcia: </h2>
    <div class="container">
        
        <?php $__currentLoopData = $wycieczkiZdj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wycieczkiZdjecia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e(url('/zrodlo_zdjecia')); ?>/<?php echo e($wycieczkiZdjecia->zrodlo_zdjecia); ?>" class="img-thumbnail" alt="...">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Semestr 6\GOT-PTTK\GOT_PTTK_Projekt\resources\views/listaturystow/szczegoly.blade.php ENDPATH**/ ?>